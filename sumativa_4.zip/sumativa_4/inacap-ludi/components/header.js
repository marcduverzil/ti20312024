export default function Header() {

  return (
    <header>
      <img src="/logo.png" alt="INACAPLudi" />

    </header>
  );
}
